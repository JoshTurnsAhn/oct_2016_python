from django.shortcuts import render, redirect
import string
import random

random = ''.join(random.choice(string.digits + string.uppercase) for n in range(14))

def index(request):
    if 'count' not in request.session:
        request.session['count'] = 0
    return render(request, 'randomword/index.html')

def generate(request):
    request.session['count'] += 1
    context = {
    'attempt': random
    }
    if request.method == "POST":
        return render(request, 'randomword/index.html', context)
    else:
        return redirect('/')


def reset(request):
    if request.method == 'GET':
      try:
           del request.session['attempts']
      except:
            pass
      return redirect('/')
# Create your views here.
