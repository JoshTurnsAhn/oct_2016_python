from django.shortcuts import render, HttpResponse, redirect, session
from random import randint
import time
  # While Django will automatically create the request object for us that's passed into our method, HttpResponse objects are our responsibility to create and return to the browser.
  #  Note that 'render' is a shortcut method that combines a given template with a given context dictionary and returns an HttpResponse object with that rendered text.
  # Create your views here.
def index(request):
    if 'gold' not in session:
        request.session['gold'] = 0
    if 'activity' not in session:
        request.session['activity'] = []
    return render(request, "index.html")

def process(request):
    data = {"farm": randint(10,20), "cave":randint(5,10), "house":randint(2,5), "casino":randint(-50,50)} #collecting a dictionary of output for each item.
    building = request.form['building']        #pull the info from the html
    gold = data[building]
    now = time.strftime("%Y-%m-%d %I:%M:%S %p") #time function
    act = {}  #will fill upon users session
    if gold > 0:
        act = {"status":"earn", "log":"Earned {} golds from the {}! ({})".format(gold, building, now)}  # the order in which goes inside each {} is in formats (1 ,2 ,3 ) ex. = {1:rules}..
    elif gold < 0:
        act = {"status":"lost", "log":"Entered a casino and lost {} golds... Ouch.. ({})".format(-gold, now)}
    else:
        act = {"status":"null", "log":"Entered a casino and got nothing... ({})".format(now)}       # different outcomes of golds variable
    request.session['gold'] += gold     # now lets show them what they got
    request.session['activity'].append(act) # and show the activity log
    return redirect('/')

def reset(request):
    session.clear()
    return redirect('/')
