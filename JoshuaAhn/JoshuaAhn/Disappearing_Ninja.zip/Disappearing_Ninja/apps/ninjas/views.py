from django.shortcuts import render, HttpResponse, redirect
  # While Django will automatically create the request object for us that's passed into our method, HttpResponse objects are our responsibility to create and return to the browser.
  #  Note that 'render' is a shortcut method that combines a given template with a given context dictionary and returns an HttpResponse object with that rendered text.
  # Create your views here.

ninjas = {
        'blue': 'leonardo.jpg',
        'red': 'raphael.jpg',
        'purple': 'donatello.jpg',
        'orange': 'michelangelo.jpg'
        }

def index(request):
    return render(request, "index.html")

def ninja(request):
    return render(request, "ninjas.html", dict=ninjas)

def color(request):
    which = {}
    if color == 'blue':
        which[color] = ninjas[color]
    elif color == 'purple':
        which[color] = ninjas[color]
    elif color == 'red':
        which[color] = ninjas[color]
    elif color == 'orange':
        which[color] = ninjas[color]
    else:
        which[color] = 'notapril.jpg'
    return render(request, "ninjas.html", dict=which)
